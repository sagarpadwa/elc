#include<reg51.h>
sbit GSouth=P2^1;
sbit YSouth=P3^3;
sbit RSouth=P3^2;

sbit GEast=P2^3;
sbit YEast=P3^7;
sbit REast=P3^6;

sbit GNorth=P2^0;
sbit YNorth=P3^1;
sbit RNorth=P3^0;

sbit GWest=P2^2;
sbit YWest=P3^5;
sbit RWest=P3^4;

void delay_sec(unsigned int second)
{
	unsigned int i,j;
	for(i=0;i<second;i++);
	for(j=0;j<53000;j++);
}
void main()
{
	while(1)
	{	//sequence 1
		GSouth=1;YSouth=1;RSouth=0;
		GEast=1;YEast=1;REast=0;
		GNorth=1;YNorth=1;RNorth=0;
		GWest=0;YWest=1;RWest=1;
		delay_sec(5);

		//sequence 2
		GSouth=1;YSouth=1;RSouth=0;
		GEast=1;YEast=1;REast=0;
		GNorth=1;YNorth=1;RNorth=0;
		GWest=0;YWest=0;RWest=1;

		//sequence 3
		GSouth=1;YSouth=1;RSouth=0;
		GEast=1;YEast=1;REast=0;
		GNorth=0;YNorth=1;RNorth=1;
		GWest=1;YWest=1;RWest=0;
		delay_sec(5);

		//sequence 4
		GSouth=1;YSouth=1;RSouth=0;
		GEast=1;YEast=1;REast=0;
		GNorth=0;YNorth=0;RNorth=1;
		GWest=1;YWest=1;RWest=0;
		delay_sec(5) ;

		//sequence 5
		GSouth=1;YSouth=1;RSouth=0;
		GEast=0;YEast=1;REast=1;
		GNorth=1;YNorth=1;RNorth=0;
		GWest=1;YWest=1;RWest=0;
		delay_sec(5);

		//sequence 6
		GSouth=1;YSouth=1;RSouth=0;
		GEast=0;YEast=0;REast=1;
		GNorth=1;YNorth=1;RNorth=0;
		GWest=1;YWest=1;RWest=0;
		delay_sec(5);

		//sequence 7
		GSouth=0;YSouth=1;RSouth=1;
		GEast=1;YEast=1;REast=0;
		GNorth=1;YNorth=1;RNorth=0;
		GWest=1;YWest=1;RWest=0;
		delay_sec(5);
		
		//sequence 8
		GSouth=0;YSouth=0;RSouth=1;
		GEast=1;YEast=1;REast=0;
		GNorth=1;YNorth=1;RNorth=0;
		GWest=1;YWest=1;RWest=0;
		delay_sec(5);
	}
}