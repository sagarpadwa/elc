#include<reg51.h>
sbit RS=P3^0;
sbit EN=P3^1;
void LCDcmd()
{
  RS=0;
  EN=1;
  EN=0;
}
void LCDdata()
{
  RS=1;
  EN=1;
  EN=0;
}
 void delay()
 {
  int i;
  for(i=0;i<30000;i++);
 }
 void main()
 {
   P1=0x38;
   LCDcmd();
   delay();
   P1=0x01;
   LCDcmd();
   delay();
   P1=0x0E;
   LCDcmd();
   delay();
   P1=0x80;
   LCDcmd();
   delay();
   P1=0x06;
   LCDcmd();
   delay();
   P1='p';
   LCDdata();
   delay();
   P1='A';
   LCDdata();
   delay();
   P1='l';
   LCDdata();
   delay();
   P1='l';
   LCDdata();
   delay();
   P1='a';
   LCDdata();
   delay();
   P1='v';
   LCDdata();
   delay();
	P1='i';
   LCDdata();
   delay();
   while(1);
 }